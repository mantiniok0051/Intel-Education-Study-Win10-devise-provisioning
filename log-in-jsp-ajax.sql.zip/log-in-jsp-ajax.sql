-- phpMyAdmin SQL Dump
-- version 4.3.11
-- http://www.phpmyadmin.net
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 21-04-2016 a las 06:52:15
-- Versión del servidor: 5.6.24
-- Versión de PHP: 5.5.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `log-in-jsp-ajax`
--
CREATE DATABASE IF NOT EXISTS `log-in-jsp-ajax` DEFAULT CHARACTER SET utf8 COLLATE utf8_spanish2_ci;
USE `log-in-jsp-ajax`;

DELIMITER $$
--
-- Procedimientos
--
DROP PROCEDURE IF EXISTS `login`$$
CREATE DEFINER=`tomcat`@`localhost` PROCEDURE `login`(IN `_username` VARCHAR(50), IN `_userpass` VARCHAR(100))
BEGIN
	SELECT * FROM `usuarios` WHERE `user-name` = `_username` AND `user-pass` = `_userpass`;
END$$

DROP PROCEDURE IF EXISTS `newUser`$$
CREATE DEFINER=`tomcat`@`localhost` PROCEDURE `newUser`(IN `_username` VARCHAR(50), IN `_email` VARCHAR(50), IN `_userpass` VARCHAR(100), IN `_lastsession` DATETIME)
BEGIN
	INSERT INTO `usuarios` (`user-name`, `email`, `user-pass`, `last-session`) 
				 VALUES (`_username`, `_email`, `_userpass`, `_lastsession` );
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--
-- Creación: 01-01-2016 a las 05:49:06
--

DROP TABLE IF EXISTS `usuarios`;
CREATE TABLE IF NOT EXISTS `usuarios` (
  `id-user` int(11) NOT NULL,
  `user-name` varchar(50) COLLATE utf8_spanish2_ci NOT NULL,
  `email` varchar(50) COLLATE utf8_spanish2_ci NOT NULL,
  `user-pass` varchar(100) COLLATE utf8_spanish2_ci NOT NULL,
  `last-session` datetime NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- RELACIONES PARA LA TABLA `usuarios`:
--

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id-user`, `user-name`, `email`, `user-pass`, `last-session`) VALUES
(1, 'test', 'test', 'test', '0000-00-00 00:00:00'),
(2, 'response', 'response@getWriter.com', 'f47ce0a3103414fda113e7720221f763b2218705', '2016-01-03 04:38:35'),
(3, 'usuario09', 'usuario09@server.com', '11f0ba9ee85a6cb5851672e8a6f728b6fcca52c6', '2016-01-03 01:31:22'),
(4, 'usuario09', 'usuario09@server.com', '11f0ba9ee85a6cb5851672e8a6f728b6fcca52c6', '2016-01-03 01:32:09'),
(5, 'usuario03', 'usuario03@server.com', '05e76622ca416c37ea4ecc0c0ace3dee0aceb135', '2016-01-03 01:33:21'),
(6, 'usuario02', 'usuario02@server.com', 'c142be9f6d50fe21cf2031b9815a3e51d8b49d3d', '2016-01-03 01:34:39'),
(7, 'usuario08', 'usuario08@server.com', '079643b11ea90dbee77add9a4a3da2eceb69dfe3', '2016-01-03 07:45:52');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id-user`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id-user` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
